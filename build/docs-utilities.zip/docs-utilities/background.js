// src/background.ts
var isInitialized = false;
chrome.action.onClicked.addListener((tab) => {
  if (typeof tab.id !== "number")
    return;
  if (!isInitialized) {
    isInitialized = true;
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
  }
});
