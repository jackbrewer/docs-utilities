// src/lib/constants.ts
var CLASS_TOP_LEVEL = "du-initialized";
var CLASS_RESIZING = "du--resizing";
var CLASS_DRAGGING = "du--dragging";
var CLASS_BARRIER = "du-barrier";
var CLASS_BOX = "du-box";
var CLASS_BOX_GUIDE = "du-box__guide";
var CLASS_BOX_POINT = "du-box__point";
var CLASS_DRAG = "du-box__drag";
var CLASS_BLUR = "du--blur-target";
var CLASS_TOOLBAR = "du-toolbar";
var CLASS_TOOLBAR_BUTTON = "du-toolbar__button";
var IGNORED_CLASSES = [CLASS_BOX, CLASS_BOX_GUIDE, CLASS_BARRIER];
var CANCEL_CLASSES = [
  CLASS_BOX_POINT,
  CLASS_TOOLBAR,
  CLASS_TOOLBAR_BUTTON,
  CLASS_DRAG
];
var MODES = ["select", "manual", "blur", "close"];
var FOCUS_SPACING = 12;
var IGNORED_ELEMENTS = [
  // Top-level elements
  "BODY",
  "HTML",
  // Common SVG content
  "PATH",
  "LINE",
  "POLYGON",
  "CIRCLE",
  "RECT",
  "ELLIPSE",
  "G",
  "TEXT"
];

// src/lib/filterStackedElements.ts
var filterStackedElements = ({
  stackedElements
}) => stackedElements.filter((el) => {
  if (IGNORED_ELEMENTS.includes(el.tagName)) {
    return false;
  }
  if (IGNORED_CLASSES.some((className) => el.classList.contains(className))) {
    return false;
  }
  if (el.children.length > 0 && el.children[0].offsetWidth === el.offsetWidth && el.children[0].offsetHeight === el.offsetHeight) {
    return false;
  }
  return true;
});

// src/lib/handleBlurClick.ts
var handleBlurClick = (event) => {
  const stackedElements = document.elementsFromPoint(
    event.clientX,
    event.clientY
  );
  if (stackedElements.some(
    (el) => CANCEL_CLASSES.some((className) => el.classList.contains(className))
  )) {
    return;
  }
  const targetElement = filterStackedElements({
    stackedElements
  })[0];
  if (!targetElement)
    return;
  if (targetElement.classList.contains(CLASS_BLUR)) {
    targetElement.classList.remove(CLASS_BLUR);
  } else {
    targetElement.classList.add(CLASS_BLUR);
  }
};

// src/lib/getSelectionIndex.ts
var getSelectionIndex = ({
  possibleElements,
  isNewTopLevelElement,
  selectedElementIndex,
  isShiftPressed
}) => {
  if (selectedElementIndex === -1)
    return 0;
  if (isNewTopLevelElement)
    return 0;
  if (isShiftPressed) {
    if (selectedElementIndex - 1 < 0)
      return 0;
    return selectedElementIndex - 1;
  }
  if (selectedElementIndex + 1 > possibleElements.length - 1) {
    return possibleElements.length - 1;
  }
  return selectedElementIndex + 1;
};

// src/lib/handleFocusClick.ts
var handleFocusClick = ({
  element,
  event,
  focussedElement,
  topLevelElement
}) => {
  const stackedElements = document.elementsFromPoint(
    event.clientX,
    event.clientY
  );
  if (stackedElements.some(
    (el) => CANCEL_CLASSES.some((className) => el.classList.contains(className))
  )) {
    return;
  }
  const possibleElements = filterStackedElements({
    stackedElements
  });
  const selectedElementIndex = focussedElement ? possibleElements.indexOf(focussedElement) : -1;
  const isNewTopLevelElement = possibleElements[0] !== topLevelElement;
  const isShiftPressed = event.shiftKey;
  const targetElement = possibleElements[getSelectionIndex({
    possibleElements,
    isNewTopLevelElement,
    selectedElementIndex,
    isShiftPressed
  })];
  var rect = targetElement.getBoundingClientRect();
  element.style.top = rect.top + window.pageYOffset - FOCUS_SPACING + "px";
  element.style.left = rect.left + window.pageXOffset - FOCUS_SPACING + "px";
  element.style.width = rect.width + FOCUS_SPACING * 2 + "px";
  element.style.height = rect.height + FOCUS_SPACING * 2 + "px";
  return {
    newFocussedElement: targetElement,
    newTopLevelElement: possibleElements[0]
  };
};

// src/lib/handleModeChange.ts
var handleModeChange = (mode2) => {
  console.log("Mode changed to:", mode2);
  document.body.classList.remove(...MODES.map((m) => `du-mode--${m}`));
  document.body.classList.add(`du-mode--${mode2}`);
  return mode2;
};

// src/lib/setElementPosition.ts
var setElementPosition = ({
  element,
  x,
  y
}) => {
  element.style.left = x + "px";
  element.style.top = y + "px";
};

// src/lib/setElementSize.ts
var setElementSize = ({ element, w, h }) => {
  element.style.width = w + "px";
  element.style.height = h + "px";
};

// src/lib/template.ts
var template = `
<div class="du-box__wrapper">
  <div class="du-box js-box">
    <div class="du-box__drag js-box-drag"></div>
    <div class="du-box__guide du-box__guide--vertical"></div>
    <div class="du-box__guide du-box__guide--horizontal"></div>
    <div class="du-box__point js-box-point" data-point="left-top"></div>
    <div class="du-box__point js-box-point" data-point="center-top"></div>
    <div class="du-box__point js-box-point" data-point="right-top"></div>
    <div class="du-box__point js-box-point" data-point="left-middle"></div>
    <div class="du-box__point js-box-point" data-point="right-middle"></div>
    <div class="du-box__point js-box-point" data-point="left-bottom"></div>
    <div class="du-box__point js-box-point" data-point="center-bottom"></div>
    <div class="du-box__point js-box-point" data-point="right-bottom"></div>
  </div>
</div>
`;
var toolbar = `
<div class="du-toolbar">
  <button class="du-toolbar__button js-toolbar-button" data-mode="select" title="Focus element">
    <svg width="24px" height="24px" stroke-width="1.2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="currentColor"><path d="M21 13V8a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h7" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path><path clip-rule="evenodd" d="M20.879 16.917c.494.304.463 1.043-.045 1.101l-2.567.291-1.151 2.312c-.228.459-.933.234-1.05-.334l-1.255-6.116c-.099-.48.333-.782.75-.525l5.318 3.271z" stroke="currentColor" stroke-width="1.2"></path><path d="M12 11.01l.01-.011M16 11.01l.01-.011M8 11.01l.01-.011" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
  </button>
  <button class="du-toolbar__button js-toolbar-button" data-mode="manual" title="Manual focus">
    <svg width="24px" height="24px" stroke-width="1.2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="currentColor"><path d="M11 13.6V21H3.6a.6.6 0 01-.6-.6V13h7.4a.6.6 0 01.6.6zM11 21h3M3 13v-3M6 3H3.6a.6.6 0 00-.6.6V6M14 3h-4M21 10v4M18 3h2.4a.6.6 0 01.6.6V6M18 21h2.4a.6.6 0 00.6-.6V18M11 10h3v3" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
  </button>
  <button class="du-toolbar__button js-toolbar-button" data-mode="blur" title="Blur element">
    <svg width="24px" height="24px" stroke-width="1.2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="currentColor"><path d="M3 3l18 18M10.5 10.677a2 2 0 002.823 2.823" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M7.362 7.561C5.68 8.74 4.279 10.42 3 12c1.889 2.991 5.282 6 9 6 1.55 0 3.043-.523 4.395-1.35M12 6c4.008 0 6.701 3.158 9 6a15.66 15.66 0 01-1.078 1.5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
  </button>
  <button class="du-toolbar__button js-toolbar-button" data-mode="close" title="Hide toolbar">
    <svg width="24px" height="24px" viewBox="0 0 24 24" stroke-width="1.2" fill="none" xmlns="http://www.w3.org/2000/svg" color="currentColor"><path d="M13 6l6 6-6 6M5 6l6 6-6 6" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
  </button>
</div>
`;

// src/styles/content.css
var content_default = ".du--blur-target {\n  transition: filter 0.2s ease-in-out;\n  filter: blur(6px);\n}\n\n.du-barrier {\n  position: fixed;\n  inset: 0;\n  z-index: 999997;\n}\n\n.du-box {\n  --dot-size: 16px;\n\n  box-sizing: border-box;\n  position: absolute;\n  user-select: none;\n\n  top: 0;\n  left: 0;\n\n  z-index: 999998;\n\n  width: 100vw;\n  height: 100vh;\n  transition: all 0.2s ease-in-out;\n  box-shadow: 0 0 0 200vmax rgb(0 0 0 / 40%);\n  border-radius: 8px;\n}\n\n.du--dragging .du-box,\n.du--resizing .du-box {\n  transition: none;\n}\n\n.du-box__point {\n  box-sizing: border-box;\n  height: var(--dot-size);\n  width: var(--dot-size);\n  background-color: #1e88e5;\n  position: absolute;\n  border-radius: 100px;\n  border: 1px solid white;\n  user-select: none;\n  transition: all 0.2s ease-in-out;\n  transform: translate(-50%, -50%);\n  opacity: 0;\n  display: none;\n}\n.du-mode--manual .du-box__point {\n  display: block;\n}\n\n.du--dragging .du-box__point,\n.du--resizing .du-box__point,\n.du-box:hover .du-box__point {\n  /* transition-delay: 1s; */\n  opacity: 1;\n}\n\n.du-box__point[data-point*='top'] {\n  top: 0;\n}\n.du-box__point[data-point*='middle'] {\n  top: 50%;\n}\n.du-box__point[data-point*='bottom'] {\n  top: 100%;\n}\n\n.du-box__point[data-point*='left'] {\n  left: 0;\n}\n.du-box__point[data-point*='center'] {\n  left: 50%;\n}\n.du-box__point[data-point*='right'] {\n  left: 100%;\n}\n\n/* Cursors */\n.du-box__point[data-point*='left-top'] {\n  cursor: nwse-resize;\n}\n.du-box__point[data-point*='center-top'] {\n  cursor: ns-resize;\n}\n.du-box__point[data-point*='right-top'] {\n  cursor: nesw-resize;\n}\n.du-box__point[data-point*='left-middle'] {\n  cursor: ew-resize;\n}\n.du-box__point[data-point*='right-middle'] {\n  cursor: ew-resize;\n}\n.du-box__point[data-point*='left-bottom'] {\n  cursor: nesw-resize;\n}\n.du-box__point[data-point*='center-bottom'] {\n  cursor: ns-resize;\n}\n.du-box__point[data-point*='right-bottom'] {\n  cursor: nwse-resize;\n}\n\n/* Shrink the non-hovered handles a bit */\n.du-box:hover:has(.du-box__point:hover) .du-box__point:not(:hover) {\n  --dot-size: 8px;\n}\n\n/* Make the active point larger */\n.du-box__point:hover,\n.du-box__point:active {\n  transition-duration: 0.1s;\n  --dot-size: 20px;\n}\n\n/* DRAGGING */\n.du-box__drag {\n  position: absolute;\n  inset: 0;\n  /* background: rgb(0 255 0 / 40%); */\n  display: none;\n  cursor: move;\n}\n.du-mode--manual .du-box__drag {\n  display: block;\n}\n\n/* Guides */\n.du-box__guide {\n  position: absolute;\n  border: 1px dashed #fff;\n  transition: opacity 0.2s ease-in-out;\n  opacity: 0;\n  pointer-events: none;\n}\n:is(.du--dragging, .du--resizing) .du-box__guide {\n  opacity: 0.5;\n  display: block;\n}\n.du-box__guide--horizontal {\n  top: -1px;\n  bottom: -1px;\n  left: 50%;\n  width: 200vw;\n  transform: translateX(-50%);\n  border-width: 1px 0;\n}\n.du-box__guide--vertical {\n  left: -1px;\n  right: -1px;\n  top: 50%;\n  height: 200vh;\n  transform: translateY(-50%);\n  border-width: 0 1px;\n}\n\n/* Toolbar */\n.du-toolbar {\n  position: fixed;\n  top: 0;\n  right: 0;\n  background: #fff;\n  border-radius: 0 0 0 8px;\n  padding: 4px;\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n  z-index: 999999;\n  transition: all 0.2s ease-in-out;\n}\n.du-toolbar__button {\n  background: #fff;\n  border: 1px solid #bbb;\n  border-radius: 4px;\n  padding: 4px;\n  cursor: pointer;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 4px;\n  transition: all 0.2s ease-in-out;\n  color: #222;\n}\n.du-toolbar__button:not([disabled]):hover,\n.du-toolbar__button.is-active {\n  background: #222;\n  color: #fff;\n}\n.du-toolbar__button[disabled] {\n  opacity: 0.3;\n  cursor: not-allowed;\n}\n.du-toolbar__button svg {\n  fill: none;\n}\n.du-mode--close .du-toolbar {\n  transform: translateX(100%);\n}\n";

// src/lib/setupDefaultElements.ts
var setupDefaultElements = () => {
  var styleEl = document.createElement("style");
  styleEl.innerHTML = content_default;
  document.head.appendChild(styleEl);
  const barrierEl = document.createElement("div");
  barrierEl.classList.add(CLASS_BARRIER);
  document.body.appendChild(barrierEl);
  document.body.insertAdjacentHTML("beforeend", template);
  const box = document.querySelector(".js-box");
  if (!box) {
    throw new Error("Could not find box");
  }
  document.body.insertAdjacentHTML("beforeend", toolbar);
  return { box };
};

// src/lib/handleDrag.ts
var handleDrag = ({ element, event }) => {
  document.body.classList.add(CLASS_DRAGGING);
  const target = event.target;
  let initX = element.offsetLeft;
  let initY = element.offsetTop;
  let mousePressX = event.clientX;
  let mousePressY = event.clientY;
  function eventMoveHandler(event2) {
    setElementPosition({
      element,
      x: initX + (event2.clientX - mousePressX),
      y: initY + (event2.clientY - mousePressY)
    });
  }
  element.addEventListener("mousemove", eventMoveHandler, false);
  window.addEventListener(
    "mouseup",
    function eventEndHandler() {
      element.removeEventListener("mousemove", eventMoveHandler, false);
      window.removeEventListener("mouseup", eventEndHandler);
      document.body.classList.remove(CLASS_DRAGGING);
    },
    false
  );
};

// src/lib/setupDrag.ts
var setupDrag = ({ element }) => {
  const dragElement = element.querySelector(".js-box-drag");
  dragElement.addEventListener(
    "mousedown",
    (event) => handleDrag({
      element,
      event
    }),
    false
  );
};

// src/lib/handleResize.ts
var handleResize = ({
  element,
  event,
  left = false,
  top = false,
  xResize = false,
  yResize = false
}) => {
  document.body.classList.add(CLASS_RESIZING);
  const minWidth = 40;
  const minHeight = 40;
  const initX = element.offsetLeft;
  const initY = element.offsetTop;
  const mousePressX = event.clientX;
  const mousePressY = event.clientY;
  const initW = element.offsetWidth;
  const initH = element.offsetHeight;
  function eventMoveHandler(event2) {
    const altKey = event2.altKey;
    let wDiff = event2.clientX - mousePressX;
    let hDiff = event2.clientY - mousePressY;
    let newW = initW;
    let newH = initH;
    let newX = initX;
    let newY = initY;
    if (xResize) {
      if (left) {
        newW = altKey ? initW - wDiff * 2 : initW - wDiff;
        if (newW < minWidth)
          return;
        newX += wDiff;
      } else {
        newW = altKey ? initW + wDiff * 2 : initW + wDiff;
        if (newW < minWidth)
          return;
        if (altKey) {
          newX -= wDiff;
        }
      }
    }
    if (yResize) {
      if (top) {
        newH = altKey ? initH - hDiff * 2 : initH - hDiff;
        if (newH < minHeight)
          return;
        newY += hDiff;
      } else {
        newH = altKey ? initH + hDiff * 2 : initH + hDiff;
        if (newH < minHeight)
          return;
        if (altKey) {
          newY -= hDiff;
        }
      }
    }
    setElementSize({ element, w: newW, h: newH });
    setElementPosition({ element, x: newX, y: newY });
  }
  window.addEventListener("mousemove", eventMoveHandler, false);
  window.addEventListener(
    "mouseup",
    function eventEndHandler() {
      window.removeEventListener("mousemove", eventMoveHandler, false);
      window.removeEventListener("mouseup", eventEndHandler);
      document.body.classList.remove(CLASS_RESIZING);
    },
    false
  );
};

// src/lib/setupPoints.ts
var setupPoints = ({ element }) => {
  const resizePoints = [
    "left-top",
    "center-top",
    "right-top",
    "left-middle",
    "right-middle",
    "left-bottom",
    "center-bottom",
    "right-bottom"
  ];
  resizePoints.forEach((point) => {
    const pointElement = document.querySelector(
      `.${CLASS_BOX_POINT}[data-point="${point}"]`
    );
    pointElement.addEventListener(
      "mousedown",
      (event) => handleResize({
        element,
        event,
        left: point.includes("left"),
        top: point.includes("top"),
        xResize: point.includes("left") || point.includes("right"),
        yResize: point.includes("top") || point.includes("bottom")
      })
    );
  });
};

// src/lib/setupToolbar.ts
var validateAndUpdateMode = ({
  mode: mode2,
  onChange
}) => {
  if (mode2 && MODES.includes(mode2)) {
    return onChange(mode2);
  }
};
var setupToolbar = ({ onChange }) => {
  const toolbarButtonEls = [
    ...document.querySelectorAll(".js-toolbar-button")
  ];
  const initialEl = toolbarButtonEls[0];
  initialEl.classList.add("is-active");
  validateAndUpdateMode({
    mode: initialEl.dataset.mode,
    onChange
  });
  toolbarButtonEls.forEach((buttonEl) => {
    buttonEl.addEventListener("click", () => {
      toolbarButtonEls.forEach((buttonEl2) => {
        buttonEl2.classList.remove("is-active");
      });
      buttonEl.classList.add("is-active");
      validateAndUpdateMode({
        mode: buttonEl.dataset.mode,
        onChange
      });
    });
  });
};
var resetToolbarActiveState = () => {
  const toolbarButtonEls = [
    ...document.querySelectorAll(".js-toolbar-button")
  ];
  toolbarButtonEls.forEach((buttonEl) => {
    buttonEl.classList.remove("is-active");
  });
  const initialEl = toolbarButtonEls[0];
  initialEl.classList.add("is-active");
};

// src/content.ts
console.log("Docs Utilities: Activated!");
var mode = MODES[0];
var initialise = () => {
  document.body.classList.add(CLASS_TOP_LEVEL);
  let focussedElement = null;
  let topLevelElement = null;
  const { box } = setupDefaultElements();
  const initialWidth = 200;
  const initialHeight = 150;
  const initialX = (window.innerWidth - initialWidth) / 2;
  const initialY = (window.innerHeight - initialHeight) / 2;
  setElementPosition({ element: box, x: initialX, y: initialY });
  setElementSize({ element: box, w: initialWidth, h: initialHeight });
  const handleModeChangeWrapper = (newMode) => {
    mode = handleModeChange(newMode);
  };
  setupToolbar({ onChange: handleModeChangeWrapper });
  setupPoints({ element: box });
  setupDrag({ element: box });
  const handleDocumentClick = (event) => {
    if (mode === "blur") {
      handleBlurClick(event);
    }
    if (mode === "select") {
      let newElements = handleFocusClick({
        element: box,
        event,
        focussedElement,
        topLevelElement
      });
      if (newElements) {
        focussedElement = newElements.newFocussedElement;
        topLevelElement = newElements.newTopLevelElement;
      }
    }
  };
  document.addEventListener("mousedown", handleDocumentClick);
};
var isInitialised = document.body.classList.contains(CLASS_TOP_LEVEL);
if (isInitialised) {
  console.log("Already initialised\u2026");
  handleModeChange(MODES[0]);
  resetToolbarActiveState();
} else {
  initialise();
}
